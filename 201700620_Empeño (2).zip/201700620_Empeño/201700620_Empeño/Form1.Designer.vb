﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RadioButton_corto = New System.Windows.Forms.RadioButton()
        Me.RadioButton_largo = New System.Windows.Forms.RadioButton()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.AceptarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LimpiarListboxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LimpiarMatrixToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.CheckBox_refrigeradora = New System.Windows.Forms.CheckBox()
        Me.CheckBox_laptop = New System.Windows.Forms.CheckBox()
        Me.CheckBox_telefono = New System.Windows.Forms.CheckBox()
        Me.CheckBox_tv = New System.Windows.Forms.CheckBox()
        Me.TextBox_refrigeradora = New System.Windows.Forms.TextBox()
        Me.TextBox_laptop = New System.Windows.Forms.TextBox()
        Me.TextBox_telefono = New System.Windows.Forms.TextBox()
        Me.TextBox_tv = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox_nombre = New System.Windows.Forms.TextBox()
        Me.TextBox_cui = New System.Windows.Forms.TextBox()
        Me.TextBox_direccion = New System.Windows.Forms.TextBox()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ColumnHeader_nombre = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_cui = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_direccion = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_tipo_pago = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_televisor = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_telefono = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_laptop = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_refrigeradora = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_subtotal = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_descuento = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_total = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadioButton_corto)
        Me.GroupBox1.Controls.Add(Me.RadioButton_largo)
        Me.GroupBox1.Location = New System.Drawing.Point(24, 147)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(158, 49)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Tipo Plazo:"
        '
        'RadioButton_corto
        '
        Me.RadioButton_corto.AutoSize = True
        Me.RadioButton_corto.Location = New System.Drawing.Point(77, 19)
        Me.RadioButton_corto.Name = "RadioButton_corto"
        Me.RadioButton_corto.Size = New System.Drawing.Size(50, 17)
        Me.RadioButton_corto.TabIndex = 4
        Me.RadioButton_corto.TabStop = True
        Me.RadioButton_corto.Text = "Corto"
        Me.RadioButton_corto.UseVisualStyleBackColor = True
        '
        'RadioButton_largo
        '
        Me.RadioButton_largo.AutoSize = True
        Me.RadioButton_largo.Location = New System.Drawing.Point(19, 19)
        Me.RadioButton_largo.Name = "RadioButton_largo"
        Me.RadioButton_largo.Size = New System.Drawing.Size(52, 17)
        Me.RadioButton_largo.TabIndex = 3
        Me.RadioButton_largo.TabStop = True
        Me.RadioButton_largo.Text = "Largo"
        Me.RadioButton_largo.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AceptarToolStripMenuItem, Me.LimpiarListboxToolStripMenuItem, Me.LimpiarMatrixToolStripMenuItem, Me.SalirToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(713, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'AceptarToolStripMenuItem
        '
        Me.AceptarToolStripMenuItem.Name = "AceptarToolStripMenuItem"
        Me.AceptarToolStripMenuItem.Size = New System.Drawing.Size(60, 20)
        Me.AceptarToolStripMenuItem.Text = "Aceptar"
        '
        'LimpiarListboxToolStripMenuItem
        '
        Me.LimpiarListboxToolStripMenuItem.Name = "LimpiarListboxToolStripMenuItem"
        Me.LimpiarListboxToolStripMenuItem.Size = New System.Drawing.Size(100, 20)
        Me.LimpiarListboxToolStripMenuItem.Text = "Limpiar Listbox"
        '
        'LimpiarMatrixToolStripMenuItem
        '
        Me.LimpiarMatrixToolStripMenuItem.Name = "LimpiarMatrixToolStripMenuItem"
        Me.LimpiarMatrixToolStripMenuItem.Size = New System.Drawing.Size(95, 20)
        Me.LimpiarMatrixToolStripMenuItem.Text = "Limpiar Matriz"
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.SalirToolStripMenuItem.Text = "Salir"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.CheckBox_refrigeradora)
        Me.GroupBox2.Controls.Add(Me.CheckBox_laptop)
        Me.GroupBox2.Controls.Add(Me.CheckBox_telefono)
        Me.GroupBox2.Controls.Add(Me.CheckBox_tv)
        Me.GroupBox2.Controls.Add(Me.TextBox_refrigeradora)
        Me.GroupBox2.Controls.Add(Me.TextBox_laptop)
        Me.GroupBox2.Controls.Add(Me.TextBox_telefono)
        Me.GroupBox2.Controls.Add(Me.TextBox_tv)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(368, 35)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(321, 161)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Tipo Aparato:"
        '
        'CheckBox_refrigeradora
        '
        Me.CheckBox_refrigeradora.AutoSize = True
        Me.CheckBox_refrigeradora.Location = New System.Drawing.Point(16, 117)
        Me.CheckBox_refrigeradora.Name = "CheckBox_refrigeradora"
        Me.CheckBox_refrigeradora.Size = New System.Drawing.Size(90, 17)
        Me.CheckBox_refrigeradora.TabIndex = 12
        Me.CheckBox_refrigeradora.Text = "Refrigeradora"
        Me.CheckBox_refrigeradora.UseVisualStyleBackColor = True
        '
        'CheckBox_laptop
        '
        Me.CheckBox_laptop.AutoSize = True
        Me.CheckBox_laptop.Location = New System.Drawing.Point(16, 90)
        Me.CheckBox_laptop.Name = "CheckBox_laptop"
        Me.CheckBox_laptop.Size = New System.Drawing.Size(59, 17)
        Me.CheckBox_laptop.TabIndex = 11
        Me.CheckBox_laptop.Text = "Laptop"
        Me.CheckBox_laptop.UseVisualStyleBackColor = True
        '
        'CheckBox_telefono
        '
        Me.CheckBox_telefono.AutoSize = True
        Me.CheckBox_telefono.Location = New System.Drawing.Point(16, 61)
        Me.CheckBox_telefono.Name = "CheckBox_telefono"
        Me.CheckBox_telefono.Size = New System.Drawing.Size(68, 17)
        Me.CheckBox_telefono.TabIndex = 10
        Me.CheckBox_telefono.Text = "Telefono"
        Me.CheckBox_telefono.UseVisualStyleBackColor = True
        '
        'CheckBox_tv
        '
        Me.CheckBox_tv.AutoSize = True
        Me.CheckBox_tv.Location = New System.Drawing.Point(16, 35)
        Me.CheckBox_tv.Name = "CheckBox_tv"
        Me.CheckBox_tv.Size = New System.Drawing.Size(69, 17)
        Me.CheckBox_tv.TabIndex = 6
        Me.CheckBox_tv.Text = "Televisor"
        Me.CheckBox_tv.UseVisualStyleBackColor = True
        '
        'TextBox_refrigeradora
        '
        Me.TextBox_refrigeradora.Location = New System.Drawing.Point(109, 114)
        Me.TextBox_refrigeradora.Name = "TextBox_refrigeradora"
        Me.TextBox_refrigeradora.Size = New System.Drawing.Size(195, 20)
        Me.TextBox_refrigeradora.TabIndex = 9
        Me.TextBox_refrigeradora.Text = "0"
        '
        'TextBox_laptop
        '
        Me.TextBox_laptop.Location = New System.Drawing.Point(109, 88)
        Me.TextBox_laptop.Name = "TextBox_laptop"
        Me.TextBox_laptop.Size = New System.Drawing.Size(195, 20)
        Me.TextBox_laptop.TabIndex = 8
        Me.TextBox_laptop.Text = "0"
        '
        'TextBox_telefono
        '
        Me.TextBox_telefono.Location = New System.Drawing.Point(109, 58)
        Me.TextBox_telefono.Name = "TextBox_telefono"
        Me.TextBox_telefono.Size = New System.Drawing.Size(195, 20)
        Me.TextBox_telefono.TabIndex = 7
        Me.TextBox_telefono.Text = "0"
        '
        'TextBox_tv
        '
        Me.TextBox_tv.Location = New System.Drawing.Point(109, 32)
        Me.TextBox_tv.Name = "TextBox_tv"
        Me.TextBox_tv.Size = New System.Drawing.Size(195, 20)
        Me.TextBox_tv.TabIndex = 6
        Me.TextBox_tv.Text = "0"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(115, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Costo Aparato:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(21, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Nombre:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(21, 78)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(25, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Cui:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(21, 112)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Dirección:"
        '
        'TextBox_nombre
        '
        Me.TextBox_nombre.Location = New System.Drawing.Point(87, 44)
        Me.TextBox_nombre.Name = "TextBox_nombre"
        Me.TextBox_nombre.Size = New System.Drawing.Size(262, 20)
        Me.TextBox_nombre.TabIndex = 9
        '
        'TextBox_cui
        '
        Me.TextBox_cui.Location = New System.Drawing.Point(87, 75)
        Me.TextBox_cui.Name = "TextBox_cui"
        Me.TextBox_cui.Size = New System.Drawing.Size(262, 20)
        Me.TextBox_cui.TabIndex = 10
        '
        'TextBox_direccion
        '
        Me.TextBox_direccion.Location = New System.Drawing.Point(87, 107)
        Me.TextBox_direccion.Name = "TextBox_direccion"
        Me.TextBox_direccion.Size = New System.Drawing.Size(262, 20)
        Me.TextBox_direccion.TabIndex = 11
        '
        'ListView1
        '
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_nombre, Me.ColumnHeader_cui, Me.ColumnHeader_direccion, Me.ColumnHeader_tipo_pago, Me.ColumnHeader_televisor, Me.ColumnHeader_telefono, Me.ColumnHeader_laptop, Me.ColumnHeader_refrigeradora, Me.ColumnHeader_subtotal, Me.ColumnHeader_descuento, Me.ColumnHeader_total})
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(24, 215)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(665, 210)
        Me.ListView1.TabIndex = 12
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'ColumnHeader_nombre
        '
        Me.ColumnHeader_nombre.Text = "NOMBRE"
        '
        'ColumnHeader_cui
        '
        Me.ColumnHeader_cui.Text = "CUI"
        '
        'ColumnHeader_direccion
        '
        Me.ColumnHeader_direccion.Text = "DIRECCION"
        '
        'ColumnHeader_tipo_pago
        '
        Me.ColumnHeader_tipo_pago.Text = "TIPO_PAGO"
        '
        'ColumnHeader_televisor
        '
        Me.ColumnHeader_televisor.Text = "COSTO_TELEVISOR"
        '
        'ColumnHeader_telefono
        '
        Me.ColumnHeader_telefono.Text = "COSTO_TELEFONO"
        '
        'ColumnHeader_laptop
        '
        Me.ColumnHeader_laptop.Text = "COSTO_LAPTOP"
        '
        'ColumnHeader_refrigeradora
        '
        Me.ColumnHeader_refrigeradora.Text = "COSTO_REFRIGERADORA"
        '
        'ColumnHeader_subtotal
        '
        Me.ColumnHeader_subtotal.Text = "SUBTOTAL"
        '
        'ColumnHeader_descuento
        '
        Me.ColumnHeader_descuento.Text = "DESCUENTO"
        '
        'ColumnHeader_total
        '
        Me.ColumnHeader_total.Text = "TOTAL"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(713, 450)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.TextBox_direccion)
        Me.Controls.Add(Me.TextBox_cui)
        Me.Controls.Add(Me.TextBox_nombre)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "201700620_EMPEÑO"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents AceptarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LimpiarListboxToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LimpiarMatrixToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents RadioButton_corto As RadioButton
    Friend WithEvents RadioButton_largo As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents TextBox_laptop As TextBox
    Friend WithEvents TextBox_telefono As TextBox
    Friend WithEvents TextBox_tv As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents CheckBox_refrigeradora As CheckBox
    Friend WithEvents CheckBox_laptop As CheckBox
    Friend WithEvents CheckBox_telefono As CheckBox
    Friend WithEvents CheckBox_tv As CheckBox
    Friend WithEvents TextBox_refrigeradora As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBox_nombre As TextBox
    Friend WithEvents TextBox_cui As TextBox
    Friend WithEvents TextBox_direccion As TextBox
    Friend WithEvents ListView1 As ListView
    Friend WithEvents ColumnHeader_nombre As ColumnHeader
    Friend WithEvents ColumnHeader_cui As ColumnHeader
    Friend WithEvents ColumnHeader_direccion As ColumnHeader
    Friend WithEvents ColumnHeader_tipo_pago As ColumnHeader
    Friend WithEvents ColumnHeader_televisor As ColumnHeader
    Friend WithEvents ColumnHeader_telefono As ColumnHeader
    Friend WithEvents ColumnHeader_laptop As ColumnHeader
    Friend WithEvents ColumnHeader_refrigeradora As ColumnHeader
    Friend WithEvents ColumnHeader_subtotal As ColumnHeader
    Friend WithEvents ColumnHeader_descuento As ColumnHeader
    Friend WithEvents ColumnHeader_total As ColumnHeader
End Class
