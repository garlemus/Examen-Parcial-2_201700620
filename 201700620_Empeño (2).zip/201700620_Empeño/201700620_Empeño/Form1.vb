﻿Public Class Form1

    Dim empenios(5, 10) As String
    Dim contador_empenios As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        contador_empenios = 0
    End Sub

    Private Sub AceptarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AceptarToolStripMenuItem.Click

        Dim nombre As String = TextBox_nombre.Text
        Dim cui As String = TextBox_cui.Text
        Dim direccion As String = TextBox_direccion.Text
        Dim tipo_pago As String = ""
        Dim monto_tv As Double = TextBox_tv.Text
        Dim monto_telefono As Double = TextBox_telefono.Text
        Dim monto_laptop As Double = TextBox_laptop.Text
        Dim monto_refrigeradora As Double = TextBox_refrigeradora.Text
        Dim descuento1 As Double = 0.0
        Dim descuento2 As Double = 0.0

        If RadioButton_corto.Checked Then
            tipo_pago = "Corto"
            If CheckBox_tv.Checked Then
                monto_tv = monto_tv + 250.0
                If CheckBox_refrigeradora.Checked Then
                    descuento1 = 0.15
                End If
            End If
                If CheckBox_telefono.Checked Then
                monto_telefono = monto_telefono + 550.0
                If CheckBox_laptop.Checked Then
                    descuento2 = 0.05
                End If
            End If
            If CheckBox_laptop.Checked Then
                monto_laptop = monto_laptop + 770.0
            End If
            If CheckBox_refrigeradora.Checked Then
                monto_refrigeradora = monto_refrigeradora + 1000.0
            End If
        ElseIf RadioButton_largo.Checked Then
            tipo_pago = "Largo"
            If CheckBox_tv.Checked Then
                monto_tv = monto_tv + 300.0
                If CheckBox_refrigeradora.Checked Then
                    descuento1 = 0.05
                End If
            End If
            If CheckBox_telefono.Checked Then
                monto_telefono = monto_telefono + 600.0
                If CheckBox_laptop.Checked Then
                    descuento2 = 0.1
                End If
            End If
            If CheckBox_laptop.Checked Then
                monto_laptop = monto_laptop + 800.0
            End If
            If CheckBox_refrigeradora.Checked Then
                monto_refrigeradora = monto_refrigeradora + 1200.0
            End If
        Else
            MsgBox("¡ERROR! Se debe de seleccionar el tipo de pago.")
            Return
        End If

        Dim subtotal As Double = monto_tv + monto_telefono + monto_laptop + monto_refrigeradora
        Dim descuento As Double = subtotal * descuento1 + subtotal * descuento2
        Dim total As Double = subtotal - descuento

        empenios(contador_empenios, 0) = nombre
        empenios(contador_empenios, 1) = cui
        empenios(contador_empenios, 2) = direccion
        empenios(contador_empenios, 3) = tipo_pago
        empenios(contador_empenios, 4) = Math.Round(monto_tv, 2).ToString()
        empenios(contador_empenios, 5) = Math.Round(monto_telefono, 2).ToString()
        empenios(contador_empenios, 6) = Math.Round(monto_laptop, 2).ToString()
        empenios(contador_empenios, 7) = Math.Round(monto_refrigeradora, 2).ToString()
        empenios(contador_empenios, 8) = Math.Round(subtotal, 2).ToString()
        empenios(contador_empenios, 9) = Math.Round(descuento, 2).ToString()
        empenios(contador_empenios, 10) = Math.Round(total, 2).ToString()


        ListView1.Items.Add(empenios(contador_empenios, 0))
        ListView1.Items.Add(empenios(contador_empenios, 1))
        ListView1.Items.Add(empenios(contador_empenios, 2))
        ListView1.Items.Add(empenios(contador_empenios, 3))
        ListView1.Items.Add(empenios(contador_empenios, 4))
        ListView1.Items.Add(empenios(contador_empenios, 5))
        ListView1.Items.Add(empenios(contador_empenios, 6))
        ListView1.Items.Add(empenios(contador_empenios, 7))
        ListView1.Items.Add(empenios(contador_empenios, 8))
        ListView1.Items.Add(empenios(contador_empenios, 9))
        ListView1.Items.Add(empenios(contador_empenios, 10))
        contador_empenios = contador_empenios + 1

    End Sub

    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click
        Dim result = MsgBox("¿Estás seguro de querer salir?", vbYesNo)
        If result = vbYes Then
            Application.Exit()
        End If
    End Sub

    Private Sub LimpiarMatrixToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LimpiarMatrixToolStripMenuItem.Click
        contador_empenios = 0
        MsgBox("Matriz limpiada correctamente.")
    End Sub

    Private Sub LimpiarListboxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LimpiarListboxToolStripMenuItem.Click
        ListView1.Clear()
        MsgBox("ListView limpiado correctamente.")
    End Sub
End Class
